import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  server: {
    port: 3000,
    // Proxy API calls to FastAPI during development
    proxy: {
      "/recommend": "http://localhost:8000",
      "/books":     "http://localhost:8000",
      "/health":    "http://localhost:8000",
    },
  },
});
